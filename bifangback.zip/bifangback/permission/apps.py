from django.apps import AppConfig


class PermissionConfig(AppConfig):
    name = 'permission'
