#!/usr/bin/env bash
source /root/bifangback_py_venv/bin/activate
sh gunicorn.cmd start