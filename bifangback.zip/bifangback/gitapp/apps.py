from django.apps import AppConfig


class GitappConfig(AppConfig):
    name = 'gitapp'
