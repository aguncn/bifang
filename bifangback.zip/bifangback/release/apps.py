from django.apps import AppConfig


class ReleaseConfig(AppConfig):
    name = 'release'
