from django.apps import AppConfig


class EnvConfig(AppConfig):
    name = 'env'
